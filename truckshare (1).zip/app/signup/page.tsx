"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { MobileLayout } from "@/components/mobile-layout"
import { Logo } from "@/components/logo"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"

export default function SignupPage() {
  const router = useRouter()
  const [userType, setUserType] = useState<"transporter" | "shipper" | null>(null)
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    name: "",
    companyName: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleNext = (e: React.FormEvent) => {
    e.preventDefault()
    setStep(2)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!userType) return

    // In a real app, you would register the user here
    router.push(userType === "transporter" ? "/dashboard/transporter" : "/dashboard/shipper")
  }

  return (
    <MobileLayout showNav={false} showStatusBar={true}>
      <div className="flex flex-col items-center justify-center h-full py-8 gap-6">
        <div className="fade-in">
          <Logo size="md" />
        </div>

        <div className="w-full max-w-sm space-y-6 slide-in">
          {step === 1 ? (
            <>
              <h1 className="text-2xl font-bold text-center">Create Account</h1>
              <div className="flex gap-2 w-full">
                <Button
                  variant={userType === "transporter" ? "default" : "secondary"}
                  className="flex-1"
                  onClick={() => setUserType("transporter")}
                >
                  Transporter
                </Button>
                <Button
                  variant={userType === "shipper" ? "default" : "secondary"}
                  className="flex-1"
                  onClick={() => setUserType("shipper")}
                >
                  Shipper
                </Button>
              </div>

              <form onSubmit={handleNext} className="space-y-4">
                <div className="space-y-2">
                  {userType === "transporter" ? (
                    <Input name="name" placeholder="Full Name" value={formData.name} onChange={handleChange} required />
                  ) : userType === "shipper" ? (
                    <Input
                      name="companyName"
                      placeholder="Company Name"
                      value={formData.companyName}
                      onChange={handleChange}
                      required
                    />
                  ) : null}
                  <Input
                    type="email"
                    name="email"
                    placeholder="Email Address"
                    value={formData.email}
                    onChange={handleChange}
                    required
                  />
                  <Input
                    type="tel"
                    name="phone"
                    placeholder="Phone Number"
                    value={formData.phone}
                    onChange={handleChange}
                    required
                  />
                </div>
                <Button type="submit" className="w-full" disabled={!userType}>
                  Next
                </Button>
              </form>
            </>
          ) : (
            <>
              <div className="flex items-center">
                <Button variant="ghost" size="icon" onClick={() => setStep(1)}>
                  <ArrowLeft className="h-5 w-5" />
                </Button>
                <h1 className="text-xl font-bold flex-1 text-center">Set Password</h1>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Input
                    type="password"
                    name="password"
                    placeholder="Password"
                    value={formData.password}
                    onChange={handleChange}
                    required
                  />
                  <Input
                    type="password"
                    name="confirmPassword"
                    placeholder="Confirm Password"
                    value={formData.confirmPassword}
                    onChange={handleChange}
                    required
                  />
                </div>
                <Button type="submit" className="w-full">
                  Create Account
                </Button>
              </form>
            </>
          )}

          <div className="text-center text-sm">
            Already have an account?{" "}
            <Link href="/login" className="text-primary font-medium">
              Log In
            </Link>
          </div>
        </div>
      </div>
    </MobileLayout>
  )
}

