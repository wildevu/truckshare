"use client"

import type React from "react"

import { useState } from "react"
import { MobileLayout } from "@/components/mobile-layout"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Filter, MapPin, Package, Star, Truck } from "lucide-react"
import Link from "next/link"

// Mock data for available loads
const MOCK_LOADS = [
  {
    id: 1,
    route: "Algiers → Oran",
    cargo: "Furniture",
    weight: "20 tons",
    price: "45,000",
    status: "in-transit",
    time: "Today, 14:30",
  },
  {
    id: 2,
    route: "Constantine → Annaba",
    cargo: "Electronics",
    weight: "15 tons",
    price: "35,000",
    status: "pending",
    time: "Tomorrow, 09:00",
  },
]

// Mock data for available trucks
const MOCK_TRUCKS = [
  {
    id: 1,
    type: "Semi-Trailer Truck",
    capacity: "25 tons",
    location: "Constantine",
    rating: 4.8,
    available: true,
  },
  {
    id: 2,
    type: "Box Truck",
    capacity: "10 tons",
    location: "Algiers",
    rating: 4.5,
    available: true,
  },
]

export default function ShipperDashboard() {
  const [searchQuery, setSearchQuery] = useState("")

  return (
    <MobileLayout>
      <div className="py-2 space-y-6">
        <div className="flex items-center gap-3">
          <Avatar className="h-10 w-10 border">
            <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Ahmed" />
            <AvatarFallback>A</AvatarFallback>
          </Avatar>
          <div>
            <h2 className="font-semibold">Hello, Ahmed</h2>
            <p className="text-sm text-muted-foreground">Shipper Account</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Input
              placeholder="Search for trucks or loads..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          </div>
          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
          </Button>
        </div>

        <div className="grid grid-cols-2 gap-3 fade-in">
          <Button
            size="lg"
            className="h-14 bg-primary hover:bg-primary/90"
            onClick={() => (window.location.href = "/search")}
          >
            <Truck className="mr-2 h-5 w-5" />
            Find Trucks
          </Button>
          <Button
            size="lg"
            className="h-14 bg-success hover:bg-success/90"
            onClick={() => (window.location.href = "/post")}
          >
            <Package className="mr-2 h-5 w-5" />
            Post Load
          </Button>
        </div>

        <div className="space-y-4 slide-in">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold">Active Loads</h3>
            <Link href="/loads" className="text-sm text-primary">
              See All
            </Link>
          </div>

          {MOCK_LOADS.map((load) => (
            <Card key={load.id} className="overflow-hidden">
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span
                        className={`h-2 w-2 rounded-full ${load.status === "in-transit" ? "bg-success" : "bg-yellow-500"}`}
                      ></span>
                      <span className="text-sm text-muted-foreground">
                        {load.status === "in-transit" ? "In Transit" : "Pending"}
                      </span>
                    </div>
                    <div className="font-medium">{load.route}</div>
                    <div className="text-sm text-muted-foreground">
                      {load.weight} • {load.cargo}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold">DZD {load.price}</div>
                    <div className="text-sm text-muted-foreground">{load.time}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="space-y-4 slide-in" style={{ animationDelay: "0.1s" }}>
          <div className="flex items-center justify-between">
            <h3 className="font-semibold">Available Trucks</h3>
            <Link href="/search" className="text-sm text-primary">
              View Map
            </Link>
          </div>

          {MOCK_TRUCKS.map((truck) => (
            <Card key={truck.id} className="overflow-hidden">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <div className="bg-muted rounded-md p-2">
                    <Truck className="h-8 w-8 text-primary" />
                  </div>
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">{truck.type}</div>
                      <div className="flex items-center">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        <span className="ml-1 text-sm font-medium">{truck.rating}</span>
                      </div>
                    </div>
                    <div className="text-sm text-muted-foreground">Capacity: {truck.capacity} • Available Now</div>
                    <div className="flex items-center text-sm text-muted-foreground">
                      <MapPin className="mr-1 h-3 w-3" />
                      {truck.location}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </MobileLayout>
  )
}

function Search(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="11" cy="11" r="8" />
      <path d="m21 21-4.3-4.3" />
    </svg>
  )
}

