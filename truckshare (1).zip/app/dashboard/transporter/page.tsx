"use client"

import { MobileLayout } from "@/components/mobile-layout"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowUpRight, Calendar, History, MapPin, Package, Truck } from "lucide-react"
import Link from "next/link"

// Mock data for available loads
const MOCK_LOADS = [
  {
    id: 1,
    route: "Alger → Oran",
    cargo: "Marchandises générales",
    weight: "2.5 tonnes",
    price: "25,000",
    date: "Demain",
  },
  {
    id: 2,
    route: "Constantine → Annaba",
    cargo: "Produits alimentaires",
    weight: "1.8 tonnes",
    price: "18,000",
    date: "23 Jan 2025",
  },
  {
    id: 3,
    route: "Sétif → Batna",
    cargo: "Matériaux de construction",
    weight: "3.2 tonnes",
    price: "22,000",
    date: "25 Jan 2025",
  },
]

export default function TransporterDashboard() {
  return (
    <MobileLayout>
      <div className="py-2 space-y-6">
        <div className="flex items-center gap-3">
          <Avatar className="h-10 w-10 border">
            <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Ahmed" />
            <AvatarFallback>A</AvatarFallback>
          </Avatar>
          <div>
            <h2 className="font-semibold">Bonjour, Ahmed</h2>
            <p className="text-sm text-muted-foreground">Transporteur</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 fade-in">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-primary mb-1">
                <Truck className="h-4 w-4" />
                <span className="text-sm font-medium">Voyages</span>
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-bold">24</span>
                <span className="text-xs text-success font-medium">+12% ce mois</span>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-success mb-1">
                <ArrowUpRight className="h-4 w-4" />
                <span className="text-sm font-medium">Revenus</span>
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-bold">45k DA</span>
                <span className="text-xs text-success font-medium">+8% ce mois</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4 slide-in">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold">Charges Disponibles</h3>
            <Link href="/loads/available" className="text-sm text-primary">
              Voir Tout
            </Link>
          </div>

          {MOCK_LOADS.map((load) => (
            <Card key={load.id} className="overflow-hidden mb-3">
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <div className="font-medium">{load.route}</div>
                    <div className="text-sm text-muted-foreground">{load.cargo}</div>
                    <div className="flex items-center gap-3 mt-1">
                      <div className="flex items-center text-xs text-muted-foreground">
                        <Package className="mr-1 h-3 w-3" />
                        {load.weight}
                      </div>
                      <div className="flex items-center text-xs text-muted-foreground">
                        <Calendar className="mr-1 h-3 w-3" />
                        {load.date}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold text-primary">{load.price} DA</div>
                    <Button variant="outline" size="sm" className="mt-2">
                      Détails
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="space-y-4 slide-in" style={{ animationDelay: "0.1s" }}>
          <h3 className="font-semibold">Actions Rapides</h3>

          <div className="grid grid-cols-3 gap-3">
            <Button variant="outline" className="h-auto py-4 flex flex-col items-center">
              <Truck className="h-5 w-5 mb-1" />
              <span className="text-xs">Ajouter un véhicule</span>
            </Button>
            <Button variant="outline" className="h-auto py-4 flex flex-col items-center">
              <MapPin className="h-5 w-5 mb-1" />
              <span className="text-xs">Planifier un trajet</span>
            </Button>
            <Button variant="outline" className="h-auto py-4 flex flex-col items-center">
              <History className="h-5 w-5 mb-1" />
              <span className="text-xs">Historique</span>
            </Button>
          </div>
        </div>
      </div>
    </MobileLayout>
  )
}

