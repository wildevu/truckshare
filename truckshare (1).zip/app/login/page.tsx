"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { MobileLayout } from "@/components/mobile-layout"
import { Logo } from "@/components/logo"
import Link from "next/link"

export default function LoginPage() {
  const router = useRouter()
  const [userType, setUserType] = useState<"transporter" | "shipper" | null>(null)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    if (!userType) return

    // In a real app, you would authenticate the user here
    router.push(userType === "transporter" ? "/dashboard/transporter" : "/dashboard/shipper")
  }

  return (
    <MobileLayout showNav={false} showStatusBar={true}>
      <div className="flex flex-col items-center justify-center h-full py-8 gap-8">
        <div className="fade-in">
          <Logo size="lg" />
        </div>

        <div className="w-full max-w-sm space-y-6 slide-in">
          <div className="flex gap-2 w-full">
            <Button
              variant={userType === "transporter" ? "default" : "secondary"}
              className="flex-1"
              onClick={() => setUserType("transporter")}
            >
              Transporter
            </Button>
            <Button
              variant={userType === "shipper" ? "default" : "secondary"}
              className="flex-1"
              onClick={() => setUserType("shipper")}
            >
              Shipper
            </Button>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <Input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <Button type="submit" className="w-full" disabled={!userType}>
              Log In
            </Button>
          </form>

          <div className="text-center text-sm">
            Don't have an account?{" "}
            <Link href="/signup" className="text-primary font-medium">
              Sign Up
            </Link>
          </div>
        </div>
      </div>
    </MobileLayout>
  )
}

