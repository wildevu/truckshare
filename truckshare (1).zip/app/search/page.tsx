"use client"

import { useState, useEffect } from "react"
import { MobileLayout } from "@/components/mobile-layout"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Filter, MapPin, SearchIcon, Truck } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"

// Mock data for trucks
const MOCK_TRUCKS = [
  {
    id: 1,
    type: "Semi-Trailer",
    capacity: "25 tons",
    location: "Algiers",
    distance: "2.5 km",
    rating: 4.8,
    available: true,
  },
  {
    id: 2,
    type: "Box Truck",
    capacity: "10 tons",
    location: "Constantine",
    distance: "5 km",
    rating: 4.5,
    available: true,
  },
  {
    id: 3,
    type: "Flatbed Truck",
    capacity: "20 tons",
    location: "Oran",
    distance: "8 km",
    rating: 4.2,
    available: false,
  },
  {
    id: 4,
    type: "Refrigerated Truck",
    capacity: "15 tons",
    location: "Annaba",
    distance: "12 km",
    rating: 4.7,
    available: true,
  },
]

export default function SearchPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [view, setView] = useState<"list" | "map">("list")
  const [showFilters, setShowFilters] = useState(false)
  const [distance, setDistance] = useState([50])
  const [truckType, setTruckType] = useState<string>("")
  const [filteredTrucks, setFilteredTrucks] = useState(MOCK_TRUCKS)
  const [mapLoaded, setMapLoaded] = useState(false)

  useEffect(() => {
    // Filter trucks based on search query and filters
    let filtered = MOCK_TRUCKS

    if (searchQuery) {
      filtered = filtered.filter(
        (truck) =>
          truck.type.toLowerCase().includes(searchQuery.toLowerCase()) ||
          truck.location.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    }

    if (truckType) {
      filtered = filtered.filter((truck) => truck.type === truckType)
    }

    // Filter by distance
    filtered = filtered.filter((truck) => {
      const truckDistance = Number.parseFloat(truck.distance.split(" ")[0])
      return truckDistance <= distance[0]
    })

    setFilteredTrucks(filtered)
  }, [searchQuery, truckType, distance])

  // Simulate map loading
  useEffect(() => {
    if (view === "map") {
      const timer = setTimeout(() => {
        setMapLoaded(true)
      }, 1000)
      return () => clearTimeout(timer)
    }
  }, [view])

  return (
    <MobileLayout title="Search">
      <div className="py-2 space-y-4">
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Input
              placeholder="Search for trucks..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
            <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          </div>
          <Button
            variant={showFilters ? "default" : "outline"}
            size="icon"
            onClick={() => setShowFilters(!showFilters)}
          >
            <Filter className="h-4 w-4" />
          </Button>
        </div>

        {showFilters && (
          <Card className="slide-in">
            <CardContent className="p-4 space-y-4">
              <div className="space-y-2">
                <h3 className="text-sm font-medium">Truck Type</h3>
                <Select value={truckType} onValueChange={setTruckType}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Types" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="Semi-Trailer">Semi-Trailer</SelectItem>
                    <SelectItem value="Box Truck">Box Truck</SelectItem>
                    <SelectItem value="Flatbed Truck">Flatbed Truck</SelectItem>
                    <SelectItem value="Refrigerated Truck">Refrigerated Truck</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between">
                  <h3 className="text-sm font-medium">Maximum Distance</h3>
                  <span className="text-sm text-muted-foreground">{distance[0]} km</span>
                </div>
                <Slider defaultValue={[50]} max={100} step={1} value={distance} onValueChange={setDistance} />
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => {
                    setTruckType("")
                    setDistance([50])
                  }}
                >
                  Reset
                </Button>
                <Button className="flex-1" onClick={() => setShowFilters(false)}>
                  Apply
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue="list" className="w-full" onValueChange={(value) => setView(value as "list" | "map")}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="list">List View</TabsTrigger>
            <TabsTrigger value="map">Map View</TabsTrigger>
          </TabsList>
          <TabsContent value="list" className="mt-4 space-y-4">
            {filteredTrucks.length > 0 ? (
              filteredTrucks.map((truck) => (
                <Card key={truck.id} className="overflow-hidden">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <div className="bg-muted rounded-md p-2">
                        <Truck className="h-8 w-8 text-primary" />
                      </div>
                      <div className="flex-1 space-y-1">
                        <div className="flex items-center justify-between">
                          <div className="font-medium">{truck.type}</div>
                          <div className="flex items-center">
                            <span className="text-sm font-medium">★ {truck.rating}</span>
                          </div>
                        </div>
                        <div className="text-sm text-muted-foreground">Capacity: {truck.capacity}</div>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center text-sm text-muted-foreground">
                            <MapPin className="mr-1 h-3 w-3" />
                            {truck.location} • {truck.distance}
                          </div>
                          <Badge variant={truck.available ? "success" : "secondary"}>
                            {truck.available ? "Available" : "Busy"}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No trucks found matching your criteria</p>
              </div>
            )}
          </TabsContent>
          <TabsContent value="map" className="mt-4">
            <div className="relative bg-muted rounded-lg overflow-hidden" style={{ height: "500px" }}>
              {!mapLoaded ? (
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
                </div>
              ) : (
                <>
                  <div className="absolute inset-0">
                    <img src="/placeholder.svg?height=500&width=400" alt="Map" className="w-full h-full object-cover" />
                    {/* Map pins for trucks */}
                    <div className="absolute top-1/4 left-1/4 transform -translate-x-1/2 -translate-y-1/2">
                      <div className="bg-primary text-white p-2 rounded-full">
                        <Truck className="h-5 w-5" />
                      </div>
                    </div>
                    <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                      <div className="bg-primary text-white p-2 rounded-full">
                        <Truck className="h-5 w-5" />
                      </div>
                    </div>
                    <div className="absolute bottom-1/3 right-1/4 transform -translate-x-1/2 -translate-y-1/2">
                      <div className="bg-secondary text-secondary-foreground p-2 rounded-full">
                        <Truck className="h-5 w-5" />
                      </div>
                    </div>
                    <div className="absolute top-1/3 right-1/3 transform -translate-x-1/2 -translate-y-1/2">
                      <div className="bg-primary text-white p-2 rounded-full">
                        <Truck className="h-5 w-5" />
                      </div>
                    </div>
                    {/* Current location */}
                    <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                      <div className="bg-blue-500 rounded-full h-6 w-6 border-4 border-white shadow-lg"></div>
                      <div className="bg-blue-500/20 rounded-full h-16 w-16 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 animate-ping"></div>
                    </div>
                  </div>
                  <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
                    <Button className="shadow-lg">
                      <MapPin className="mr-2 h-4 w-4" />
                      Use Current Location
                    </Button>
                  </div>
                </>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </MobileLayout>
  )
}

