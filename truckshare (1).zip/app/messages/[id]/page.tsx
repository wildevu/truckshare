"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { MobileLayout } from "@/components/mobile-layout"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ArrowLeft, ImageIcon, Paperclip, Send } from "lucide-react"
import Link from "next/link"
import { useParams } from "next/navigation"

// Mock data for the conversation
const MOCK_CONVERSATION = {
  id: 1,
  name: "Karim Benzema",
  avatar: "/placeholder.svg?height=40&width=40",
  isOnline: true,
  isTransporter: true,
  messages: [
    {
      id: 1,
      sender: "them",
      text: "Hello, I saw your load posting from Algiers to Oran. Is it still available?",
      time: "10:00 AM",
    },
    {
      id: 2,
      sender: "me",
      text: "Yes, it's still available. It's 20 tons of furniture that needs to be delivered by tomorrow.",
      time: "10:05 AM",
    },
    {
      id: 3,
      sender: "them",
      text: "Great! I have a semi-trailer truck available. What's your budget for this delivery?",
      time: "10:10 AM",
    },
    {
      id: 4,
      sender: "me",
      text: "We're looking at around 45,000 DZD. Would that work for you?",
      time: "10:15 AM",
    },
    {
      id: 5,
      sender: "them",
      text: "That works for me. I'll be at the pickup location at 2 PM. Can you provide the exact address?",
      time: "10:30 AM",
    },
  ],
}

export default function ConversationPage() {
  const params = useParams()
  const conversationId = params.id
  const [newMessage, setNewMessage] = useState("")
  const [conversation, setConversation] = useState(MOCK_CONVERSATION)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [conversation.messages])

  const sendMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newMessage.trim()) return

    const newMsg = {
      id: conversation.messages.length + 1,
      sender: "me",
      text: newMessage,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    }

    setConversation((prev) => ({
      ...prev,
      messages: [...prev.messages, newMsg],
    }))
    setNewMessage("")
  }

  return (
    <MobileLayout showNav={true} showStatusBar={false}>
      <div className="flex flex-col h-screen">
        {/* Chat header */}
        <div className="flex items-center p-4 border-b">
          <Link href="/messages">
            <Button variant="ghost" size="icon" className="mr-2">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <Avatar className="h-10 w-10">
            <AvatarImage src={conversation.avatar} alt={conversation.name} />
            <AvatarFallback>{conversation.name.charAt(0)}</AvatarFallback>
          </Avatar>
          <div className="ml-3">
            <h2 className="font-semibold">{conversation.name}</h2>
            <div className="flex items-center">
              <div className={`h-2 w-2 rounded-full ${conversation.isOnline ? "bg-success" : "bg-muted"} mr-1`}></div>
              <span className="text-xs text-muted-foreground">{conversation.isOnline ? "Online" : "Offline"}</span>
            </div>
          </div>
        </div>

        {/* Chat messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {conversation.messages.map((message) => (
            <div key={message.id} className={`flex ${message.sender === "me" ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-[80%] rounded-lg p-3 ${
                  message.sender === "me" ? "bg-primary text-primary-foreground" : "bg-secondary"
                }`}
              >
                <p>{message.text}</p>
                <p
                  className={`text-xs mt-1 ${
                    message.sender === "me" ? "text-primary-foreground/70" : "text-muted-foreground"
                  }`}
                >
                  {message.time}
                </p>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        {/* Message input */}
        <form onSubmit={sendMessage} className="border-t p-4 flex items-center gap-2">
          <Button type="button" variant="ghost" size="icon">
            <Paperclip className="h-5 w-5" />
          </Button>
          <Button type="button" variant="ghost" size="icon">
            <ImageIcon className="h-5 w-5" />
          </Button>
          <Input
            placeholder="Type a message..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            className="flex-1"
          />
          <Button type="submit" size="icon" disabled={!newMessage.trim()}>
            <Send className="h-5 w-5" />
          </Button>
        </form>
      </div>
    </MobileLayout>
  )
}

