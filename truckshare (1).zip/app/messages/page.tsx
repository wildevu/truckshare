"use client"

import { useState } from "react"
import { MobileLayout } from "@/components/mobile-layout"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent } from "@/components/ui/card"
import { Search } from "lucide-react"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"

// Mock data for conversations
const MOCK_CONVERSATIONS = [
  {
    id: 1,
    name: "Karim Benzema",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "I'll be at the pickup location at 2 PM",
    time: "10:30 AM",
    unread: 2,
    isTransporter: true,
  },
  {
    id: 2,
    name: "Sonatrach Logistics",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "Your shipment has been confirmed",
    time: "Yesterday",
    unread: 0,
    isTransporter: false,
  },
  {
    id: 3,
    name: "Mohammed Ali",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "Can you provide more details about the cargo?",
    time: "Yesterday",
    unread: 0,
    isTransporter: true,
  },
  {
    id: 4,
    name: "Cevital Transport",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "We have a truck available for your route",
    time: "Monday",
    unread: 0,
    isTransporter: false,
  },
]

export default function MessagesPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState<"all" | "transporters" | "shippers">("all")

  const filteredConversations = MOCK_CONVERSATIONS.filter((conversation) => {
    // Filter by search query
    if (searchQuery && !conversation.name.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false
    }

    // Filter by tab
    if (activeTab === "transporters" && !conversation.isTransporter) {
      return false
    }
    if (activeTab === "shippers" && conversation.isTransporter) {
      return false
    }

    return true
  })

  return (
    <MobileLayout title="Messages">
      <div className="py-2 space-y-4">
        <div className="relative">
          <Input
            placeholder="Search conversations..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        </div>

        <Tabs
          defaultValue="all"
          className="w-full"
          onValueChange={(value) => setActiveTab(value as "all" | "transporters" | "shippers")}
        >
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="transporters">Transporters</TabsTrigger>
            <TabsTrigger value="shippers">Shippers</TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="space-y-2">
          {filteredConversations.length > 0 ? (
            filteredConversations.map((conversation) => (
              <Link href={`/messages/${conversation.id}`} key={conversation.id}>
                <Card
                  className={`hover:bg-accent transition-colors ${conversation.unread > 0 ? "border-l-4 border-l-primary" : ""}`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarImage src={conversation.avatar} alt={conversation.name} />
                        <AvatarFallback>{conversation.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-baseline">
                          <h3 className="font-medium truncate">{conversation.name}</h3>
                          <span className="text-xs text-muted-foreground">{conversation.time}</span>
                        </div>
                        <p className="text-sm text-muted-foreground truncate">{conversation.lastMessage}</p>
                      </div>
                      {conversation.unread > 0 && (
                        <div className="bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs">
                          {conversation.unread}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))
          ) : (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No conversations found</p>
            </div>
          )}
        </div>
      </div>
    </MobileLayout>
  )
}

