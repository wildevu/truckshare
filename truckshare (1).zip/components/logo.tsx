import Image from "next/image"

interface LogoProps {
  size?: "sm" | "md" | "lg"
  withText?: boolean
  className?: string
}

export function Logo({ size = "md", withText = true, className = "" }: LogoProps) {
  const sizes = {
    sm: "h-8",
    md: "h-12",
    lg: "h-16",
  }

  return (
    <div className={`flex flex-col items-center ${className}`}>
      <div className={`relative ${sizes[size]}`}>
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/fluid-truck-rental-cargo9159.logowik.com-yTU9pP5FFvnWUtGAFQV9uVsMJKoQht.webp"
          alt="FluidTruck Logo"
          width={
            withText ? (size === "lg" ? 240 : size === "md" ? 180 : 120) : size === "lg" ? 64 : size === "md" ? 48 : 32
          }
          height={size === "lg" ? 64 : size === "md" ? 48 : 32}
          className={sizes[size]}
        />
      </div>
      {withText && <p className="text-xs text-muted-foreground mt-1">Connect. Transport. Deliver.</p>}
    </div>
  )
}

