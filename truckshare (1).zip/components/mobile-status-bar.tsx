import { Bell, MessageSquare } from "lucide-react"
import type { ReactNode } from "react"
import { Button } from "@/components/ui/button"

interface MobileStatusBarProps {
  title?: string
  rightAction?: ReactNode
}

export function MobileStatusBar({ title, rightAction }: MobileStatusBarProps) {
  return (
    <div className="mobile-status-bar">
      <div className="flex items-center gap-2">
        <span>9:41</span>
        <div className="flex gap-1">
          <span className="i-lucide-signal h-4 w-4" />
          <span className="i-lucide-wifi h-4 w-4" />
          <span className="i-lucide-battery-full h-4 w-4" />
        </div>
      </div>
      {title && <div className="font-semibold">{title}</div>}
      {rightAction || (
        <div className="flex gap-2">
          <Button variant="ghost" size="icon" className="h-8 w-8">
            <Bell className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8">
            <MessageSquare className="h-5 w-5" />
          </Button>
        </div>
      )}
    </div>
  )
}

