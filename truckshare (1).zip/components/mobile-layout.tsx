import type { ReactNode } from "react"
import { MobileNav } from "./mobile-nav"
import { MobileStatusBar } from "./mobile-status-bar"

interface MobileLayoutProps {
  children: ReactNode
  showNav?: boolean
  showStatusBar?: boolean
  title?: string
  rightAction?: ReactNode
}

export function MobileLayout({
  children,
  showNav = true,
  showStatusBar = true,
  title,
  rightAction,
}: MobileLayoutProps) {
  return (
    <div className="mobile-container bg-background">
      {showStatusBar && <MobileStatusBar title={title} rightAction={rightAction} />}
      <div className="mobile-content">{children}</div>
      {showNav && <MobileNav />}
    </div>
  )
}

